<?php

$hostname = "localhost";
$username = "root";
$password = "";
$database = "plates";

$db = new mysqli($hostname, $username, $password, $database);

if ($db->connect_errno)
{
    die('Ошибка подключения '.$db->connect_error);
}

$db->set_charset('utf8');
