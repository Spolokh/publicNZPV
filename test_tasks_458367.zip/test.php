<?php

/***********************************************************************************
 ADDNEWPLATE
***********************************************************************************/


//
case addnewplate:
$title = "";
$description = "";
$thispage = "plate";
$id = $_GET['id'];
// Не думаю , что "connect.inc.php" мужно использовать после $db->query("INSERT INTO wall_plates SET
require('../../assets/connect.inc.php');
require('../../assets/admhead.inc.php');
require('../../assets/connect.inc.php');
	
echo '<div class="panel panel-default">
    <div class="panel-heading"><h1><a href="/admin/plate/">Тарелки</a> → Добавить тарелку</h1></div>
    <div class="panel-body"><!--<p>Шаг 1 - Описание тарелки → <strong>Шаг 2 - Фото тарелки</strong></p>-->
		
	';


/**
 * Или так ...
 * $editorchoice = isset($_POST['editorchoice']) ? $editorchoice = $db->real_escape_string($_POST['editorchoice']) : '';
 * Ести PDO ,то real_escape_string можно не использовать...
 * require
 */
	
if (isset($_POST['editorchoice'])) { $editorchoice = $db->real_escape_string($_POST['editorchoice']); } else {}
if (isset($_POST['editorchoice_textRU'])) { $editorchoice_textRU = $db->real_escape_string($_POST['editorchoice_textRU']); } else {}
if (isset($_POST['editorchoice_textEN'])) { $editorchoice_textEN = $db->real_escape_string($_POST['editorchoice_textEN']); } else {}
if (isset($_POST['threed'])) { $threed = $db->real_escape_string($_POST['threed']); } else {}
if (isset($_POST['bestofthreed'])) { $bestofthreed = $db->real_escape_string($_POST['bestofthreed']); } else {}
if (isset($_POST['bestofthreed_textRU'])) { $bestofthreed_textRU = $db->real_escape_string($_POST['bestofthreed_textRU']); } else {}
if (isset($_POST['bestofthreed_textEN'])) { $bestofthreed_textEN = $db->real_escape_string($_POST['bestofthreed_textEN']); } else {}
if (isset($_POST['rare'])) { $rare = $db->real_escape_string($_POST['rare']); } else {}
if (isset($_POST['rare_textRU'])) { $rare_textRU = $db->real_escape_string($_POST['rare_textRU']); } else {}
if (isset($_POST['rare_textEN'])) { $rare_textEN = $db->real_escape_string($_POST['rare_textEN']); } else {}
if (isset($_POST['top'])) { $top = $db->real_escape_string($_POST['top']); } else {}
if (isset($_POST['top_textRU'])) { $top_textRU = $db->real_escape_string($_POST['top_textRU']); } else {}
if (isset($_POST['top_textEN'])) { $top_textEN = $db->real_escape_string($_POST['top_textEN']); } else {}
if (isset($_POST['unusual'])) { $unusual = $db->real_escape_string($_POST['unusual']); } else {}
if (isset($_POST['unusual_textRU'])) { $unusual_textRU = $db->real_escape_string($_POST['unusual_textRU']); } else {}
if (isset($_POST['unusual_textEN'])) { $unusual_textEN = $db->real_escape_string($_POST['unusual_textEN']); } else {}

	
$country  = $db->real_escape_string($_POST['country']); 
$type     = $db->real_escape_string($_POST['type']);
$material = $db->real_escape_string($_POST['material']);
$titleRU  = $db->real_escape_string($_POST['titleRU']);
$title1RU = $db->real_escape_string($_POST['title1RU']);
$title2RU = $db->real_escape_string($_POST['title2RU']);
$title3RU = $db->real_escape_string($_POST['title3RU']);
$titleEN  = $db->real_escape_string($_POST['titleEN']);
$title1EN = $db->real_escape_string($_POST['title1EN']);
$title2EN = $db->real_escape_string($_POST['title2EN']);
$title3EN = $db->real_escape_string($_POST['title3EN']);
$titleES  = $db->real_escape_string($_POST['titleES']);
$textRU   = $db->real_escape_string($_POST['textRU']);
$textEN   = $db->real_escape_string($_POST['textEN']);
$textES   = $db->real_escape_string($_POST['textES']);
$noteRU   = $db->real_escape_string($_POST['noteRU']);
$noteEN   = $db->real_escape_string($_POST['noteEN']);
$size_cm  = $db->real_escape_string($_POST['size_cm']);
	
$query = $db->query("INSERT INTO wall_plates SET countryID = '$country',
        type = '$type',
        material = '$material',
        titleRU = '$titleRU', 
        title1RU = '$title1RU', 
        title2RU = '$title2RU',
        title3RU = '$title3RU',
        titleEN = '$titleEN',
        title1EN = '$title1EN',
        title2EN = '$title2EN',
        title3EN = '$title3EN',
        titleES = '$titleES',
        textRU = '$textRU',
        textEN = '$textEN',
        textES = '$textES',
        noteRU = '$noteRU',
        noteEN = '$noteEN',
        rare = '$rare',
        rare_textRU = '$rare_textRU',
        rare_textEN = '$rare_textEN',
        top = '$top',
        top_textRU = '$top_textRU',
        top_textEN = '$top_textEN',
        unusual = '$unusual',
        unusual_textRU = '$unusual_textRU',
        unusual_textEN = '$unusual_textEN',
        editorchoice = '$editorchoice',
        editorchoice_textRU = '$editorchoice_textRU',
        editorchoice_textEN = '$editorchoice_textEN',
        threed = '$threed',
        bestofthreed = '$bestofthreed',
        bestofthreed_textRU = '$bestofthreed_textRU',
        bestofthreed_textEN = '$bestofthreed_textEN',
        size_cm = '$size_cm'");
                                                
$querysubcontinent = $db->query("SELECT * FROM wall_countries WHERE ID = '$country'")
    or die ('<p>База данных временно недоступна!</p>');

$result = $querysubcontinent->fetch_all(MYSQLI_ASSOC);

foreach ($result as $rowsubcontinent) {
    $subcontinentID = $rowsubcontinent['subcontinentID'];
}

/*while ($rowsubcontinent = mysql_fetch_assoc($querysubcontinent)) {
    $subcontinentID = $rowsubcontinent['subcontinentID'];
}*/

$db->free_result($querysubcontinent);

ob_start();

	echo '<p class="bg-success"><img src="/images/loader.gif" alt="Загрузка..."/><br />Добавляем тарелку...</p>';
	
	/*echo '
			<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
			<script src="/assets/js/jquery-noconflict.js" type="text/javascript"></script> 
			<script type="text/javascript" src="/assets/js/jquery.form.js"></script>
			<script type="text/javascript">
			
			</script>';*/	
	echo '	
    </div>
  </div>
</div>';

ob_get_contents();

?>	

<script type="text/javascript">
<!-- 
function moveon(){ 
    location="/admin/plate/?action=subcontinent&id=<?=$subcontinentID?>&countryID=<?=$country?>#lastrow"; 
} 
setTimeout( 'moveon()', 1500 ); 
//--> 
</script>
<?php         
break;
?>